9 graphs of Autonomous Systems (AS) peering information inferred from Oregon route-views between March 31 2001 and May 26 2001 (one graph per week).

Important: Across networks the number of nodes increases, but apart from forming new connections, a few of the old connections are lost as well.

For more info: https://snap.stanford.edu/data/Oregon-1.html